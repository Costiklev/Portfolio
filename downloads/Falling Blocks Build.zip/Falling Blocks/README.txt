This game was made when I still had no programming and design experience so play at your own risk.

Use WASD to move around
Ctrl to boost your speed
Space to skip a level
Mouse scroll wheel to change your size (was meant for debugging)

Your goal is avoiding the blocks on the screen, after a few seconds a level section finishes and a new one starts with a different obstacle. After 5 levels there's a checkpoint.